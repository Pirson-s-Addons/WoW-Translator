local ADDON_NAME, addonTable = ...
addonTable.MazzRaidDict = {
    ["trash"] = { 
        esES = "Enemigos menores", esMX = "Enemigos menores", enUS = "Trash mobs", deDE = "Trash", 
        frFR = "Monstres", itIT = "Nemici minori", koKR = "잡몹", ptBR = "Lixo", ruRU = "Трэш", 
        zhCN = "小怪", zhTW = "小怪" 
    },
    ["wipe"] = { 
        esES = "Muerte total", esMX = "Muerte total", enUS = "Wipe", deDE = "Wipe", frFR = "Wipe", 
        itIT = "Wipe", koKR = "전멸", ptBR = "Wipe", ruRU = "Вайп", zhCN = "灭团", zhTW = "滅團" 
    },
    ["nerf"] = { 
        esES = "Reducción de poder", esMX = "Reducción de poder", enUS = "Nerf", deDE = "Nerf", 
        frFR = "Nerf", itIT = "Nerf", koKR = "너프", ptBR = "Nerf", ruRU = "Нерф", zhCN = "削弱", 
        zhTW = "削弱" 
    },
    ["ninja"] = { 
        esES = "Ladrón de botín", esMX = "Ladrón de botín", enUS = "Ninja Looter", 
        deDE = "Ninja-Looter", frFR = "Ninja looteur", itIT = "Predatore", koKR = "닌자", 
        ptBR = "Ninja Looter", ruRU = "Ниндзя-лутер", zhCN = "黑装者", zhTW = "黑裝者" 
    },
    ["boe"] = { 
        esES = "Se vincula al equipar", esMX = "Se vincula al equipar", enUS = "Bind on Equip", 
        deDE = "Beim Anlegen gebunden", frFR = "Lié cuando équipé", itIT = "Vincolato al equipagg.", 
        koKR = "착용 시 귀속", ptBR = "Vinculado ao Equipar", ruRU = "БоЕ (при надевании)", zhCN = "装绑", 
        zhTW = "裝綁" 
    },
    ["bop"] = { 
        esES = "Se vincula al recoger", esMX = "Se vincula al recoger", enUS = "Bind on Pickup", 
        deDE = "Beim Aufheben gebunden", frFR = "Lié quand ramassé", itIT = "Vincolato alla raccolta", 
        koKR = "획득 시 귀속", ptBR = "Vinculado ao Coletar", ruRU = "БоП (при поднятии)", zhCN = "拾绑", 
        zhTW = "拾綁" 
    },
    ["ml"] = { 
        esES = "Maestro despojador", esMX = "Maestro despojador", enUS = "Master Looter", 
        deDE = "Plündermeister", frFR = "Responsable du butin", itIT = "Responsabile del bottino", 
        koKR = "담당자 분배", ptBR = "Mestre Saqueador", ruRU = "МЛ (Мастер лут)", zhCN = "队长分配", 
        zhTW = "隊長分配" 
    },
    ["gdkp"] = {
        esES = "Subasta GDKP", esMX = "Subasta GDKP", enUS = "GDKP Auction", 
        deDE = "GDKP-Auktion", frFR = "Enchères GDKP", itIT = "Asta GDKP", koKR = "GDKP 경매", 
        ptBR = "Leilão GDKP", ruRU = "Аукцион GDKP", zhCN = "GDKP 拍卖", zhTW = "GDKP 拍賣"
    },
    ["repp"] = { 
        esES = "Reparar", esMX = "Reparar", enUS = "Repair", deDE = "Reparieren", frFR = "Réparer", 
        itIT = "Riparazione", koKR = "수리", ptBR = "Reparar", ruRU = "Ремонт", zhCN = "修理", zhTW = "修理" 
    },
    ["summon"] = { 
        esES = "Invocación", esMX = "Invocación", enUS = "Summon", deDE = "Beschwören", frFR = "Invoquer", 
        itIT = "Evocazione", koKR = "소환", ptBR = "Evocar", ruRU = "Summon/Суммон", zhCN = "拉人", 
        zhTW = "拉人" 
    },
    ["summ"] = { 
        esES = "Invocación", esMX = "Invocación", enUS = "Summon", deDE = "Beschwören", frFR = "Invoquer", 
        itIT = "Evocazione", koKR = "소환", ptBR = "Evocar", ruRU = "Summon/Суммон", zhCN = "拉人", 
        zhTW = "拉人" 
    },
    ["lust"] = { 
        esES = "Ansia de Sangre", esMX = "Ansia de Sangre", enUS = "Bloodlust/Heroism", deDE = "Kampfrausch", 
        frFR = "Héroïsme", itIT = "Brama di Sangue", koKR = "블러드/웅심", ptBR = "Sede de Sangue", 
        ruRU = "Героизм/БЛ", zhCN = "嗜血/英勇", zhTW = "嗜血/英勇" 
    },
    ["bl"] = { 
        esES = "Ansia de Sangre", esMX = "Ansia de Sangre", enUS = "Bloodlust/Heroism", deDE = "Kampfrausch", 
        frFR = "Héroïsme", itIT = "Brama di Sangue", koKR = "블러드/웅심", ptBR = "Sede de Sangue", 
        ruRU = "Героизм/БЛ", zhCN = "嗜血/英勇", zhTW = "嗜血/英勇" 
    },
    ["cele"] = { 
        esES = "Celestial", esMX = "Celestial", enUS = "Celestial", 
        deDE = "Cele", frFR = "Cele", itIT = "Cele", 
        koKR = "천상", ptBR = "Cele", ruRU = "Небожитель", 
        zhCN = "天神", zhTW = "天神" 
    },
    ["celes"] = { 
        esES = "Celestiales", esMX = "Celestiales", enUS = "Celestials", 
        deDE = "Celes", frFR = "Celes", itIT = "Celes", 
        koKR = "천상", ptBR = "Celes", ruRU = "Небожитель", 
        zhCN = "天神", zhTW = "天神" 
    },
    
    -- === WORLD OF WARCRAFT CLÁSICO ===
    ["rfc"] = { esES = "Sima Ígnea", esMX = "Sima Ígnea", enUS = "Ragefire Chasm", deDE = "Flammenschlund", frFR = "Gouffre de Ragefeu", itIT = "Voragine di Fuoco", koKR = "성난불꽃 협곡", ptBR = "Fosso de Chamas", ruRU = "Огненная пропасть", zhCN = "怒焰裂谷", zhTW = "怒焰裂谷" },
    ["wc"] = { esES = "Cuevas de los Lamentos", esMX = "Cuevas de los Lamentos", enUS = "Wailing Caverns", deDE = "Höhlen des Wehklagens", frFR = "Cavernes des lamentations", itIT = "Caverne del Lamento", koKR = "통곡의 동굴", ptBR = "Cavernas Gementes", ruRU = "Пещеры Стенаний", zhCN = "哀嚎洞穴", zhTW = "哀嚎洞穴" },
    ["tdm"] = { esES = "Minas de la Muerte", esMX = "Minas de la Muerte", enUS = "The Deadmines", deDE = "Die Todesminen", frFR = "Les Mortemines", itIT = "Miniere della Morte", koKR = "죽음의 폐광", ptBR = "Minas da Morte", ruRU = "Мертвые копи", zhCN = "死亡矿井", zhTW = "死亡礦井" },
    ["bfd"] = { esES = "Cavernas de Brazanegra", esMX = "Cavernas de Brazanegra", enUS = "Blackfathom Deeps", deDE = "Tiefschwarze Grotte", frFR = "Profondeurs de Brassenoire", itIT = "Abissi di Fondocupa", koKR = "검은심연 나락", ptBR = "Cavernas de Braçanegra", ruRU = "Непроглядная Пучина", zhCN = "黑暗深渊", zhTW = "黑暗深淵" },
    ["sfk"] = { esES = "Castillo de Colmillo Oscuro", esMX = "Castillo de Colmillo Oscuro", enUS = "Shadowfang Keep", deDE = "Burg Schattenfang", frFR = "Donjon d'Ombrecroc", itIT = "Forte di Zannascura", koKR = "그림자송곳니 성채", ptBR = "Berço do Medo", ruRU = "Крепость Темного Клыка", zhCN = "影牙城堡", zhTW = "影牙城堡" },
    ["stockades"] = { esES = "Las Mazmorras", esMX = "Las Mazmorras", enUS = "The Stockade", deDE = "Das Verlies", frFR = "La Prison", itIT = "La Prigione", koKR = "지하감옥", ptBR = "Andares inferiores", ruRU = "Тюрьма", zhCN = "暴风城监狱", zhTW = "暴風城監獄" },
    ["rfk"] = { esES = "Horado Rajacieno", esMX = "Horado Rajacieno", enUS = "Razorfen Kraul", deDE = "Kraal von Razorfen", frFR = "Cratère d'Un'Goro", itIT = "Sotterranei di Razorfen", koKR = "가시덩굴 우리", ptBR = "Urzes de Razorfen", ruRU = "Лабиринты Иглошкурых", zhCN = "剃刀沼泽", zhTW = "剃刀沼澤" },
    ["sm lib"] = { esES = "Monasterio Escarlata (Biblioteca)", esMX = "Monasterio Escarlata (Biblioteca)", enUS = "Scarlet Monastery (Library)", deDE = "Scharlachrotes Kloster (Bibliothek)", frFR = "Monastère (Bibliothèque)", itIT = "Monastero (Biblioteca)", koKR = "붉은십자군 수도원 (도서관)", ptBR = "Mosteiro (Biblioteca)", ruRU = "Монастырь (Библиотека)", zhCN = "血色修道院 (图书馆)", zhTW = "血色修道院 (圖書館)" },
    ["sm arm"] = { esES = "Monasterio Escarlata (Armería)", esMX = "Monasterio Escarlata (Armería)", enUS = "Scarlet Monastery (Armory)", deDE = "Scharlachrotes Kloster (Waffenkammer)", frFR = "Monastère (Armurerie)", itIT = "Monastero (Armeria)", koKR = "붉은십자군 수도원 (무기고)", ptBR = "Mosteiro (Armaria)", ruRU = "Монастырь (Оружейная)", zhCN = "血色修道院 (武器库)", zhTW = "血色修道院 (武器庫)" },
    ["sm cath"] = { esES = "Monasterio Escarlata (Catedral)", esMX = "Monasterio Escarlata (Catedral)", enUS = "Scarlet Monastery (Cathedral)", deDE = "Scharlachrotes Kloster (Kathedrale)", frFR = "Monastère (Cathédrale)", itIT = "Monastero (Cattedrale)", koKR = "붉은십자군 수도원 (대성당)", ptBR = "Mosteiro (Catedral)", ruRU = "Монастырь (Собор)", zhCN = "血色修道院 (大教堂)", zhTW = "血色修道院 (大教堂)" },
    ["rfd"] = { esES = "Zahúrda Rajacieno", esMX = "Zahúrda Rajacieno", enUS = "Razorfen Downs", deDE = "Hügel von Razorfen", frFR = "Souilles de Tranchebauge", itIT = "Alture di Razorfen", koKR = "가시덩굴 구릉", ptBR = "Ermo de Razorfen", ruRU = "Курганы Иглошкурых", zhCN = "剃刀高地", zhTW = "剃刀高地" },
    ["ulda"] = { esES = "Uldaman", esMX = "Uldaman", enUS = "Uldaman", deDE = "Uldaman", frFR = "Uldaman", itIT = "Uldaman", koKR = "울다만", ptBR = "Uldaman", ruRU = "Ульдаман", zhCN = "奥达曼", zhTW = "奧達曼" },
    ["zf"] = { esES = "Zul'Farrak", esMX = "Zul'Farrak", enUS = "Zul'Farrak", deDE = "Zul'Farrak", frFR = "Zul'Farrak", itIT = "Zul'Farrak", koKR = "줄파락", ptBR = "Zul'Farrak", ruRU = "Зул'Фаррак", zhCN = "祖尔法拉克", zhTW = "祖爾法拉克" },
    ["mara"] = { esES = "Maraudon", esMX = "Maraudon", enUS = "Maraudon", deDE = "Maraudon", frFR = "Maraudon", itIT = "Maraudon", koKR = "마라돈", ptBR = "Maraudon", ruRU = "Мародон", zhCN = "玛拉顿", zhTW = "瑪拉頓" },
    ["st"] = { esES = "El Templo de Atal'Hakkar", esMX = "El Templo de Atal'Hakkar", enUS = "Sunken Temple", deDE = "Versunkener Tempel", frFR = "Le Temple d'Atal'Hakkar", itIT = "Tempio Sommerso", koKR = "아탈학카르 신전", ptBR = "Templo Submerso", ruRU = "Затонувший Храм", zhCN = "沉没的神庙", zhTW = "沉沒的神廟" },
    ["brd"] = { esES = "Profundidades de Roca Negra", esMX = "Profundidades de Roca Negra", enUS = "Blackrock Depths", deDE = "Schwarzfelstiefen", frFR = "Profondeurs de Rochenoire", itIT = "Sotterranei di Roccianera", koKR = "검은바위 나락", ptBR = "Abismo Rocha Negra", ruRU = "Глубины Черной горы", zhCN = "黑石深渊", zhTW = "黑石深淵" },
    ["lbrs"] = { esES = "Cumbres de Roca Negra Inferior", esMX = "Cumbres de Roca Negra Inferior", enUS = "Lower Blackrock Spire", deDE = "Untere Schwarzfelsspitze", frFR = "Pic de Rochenoire inférieur", itIT = "Bastioni di Roccianera Inferiori", koKR = "검은바위 첨탑 하층", ptBR = "Pico da Rocha Negra Inferior", ruRU = "Нижняя часть Пика Черной горы", zhCN = "黑石塔下层", zhTW = "黑石塔下層" },
    ["ubrs"] = { esES = "Cumbre de Roca Negra Superior", esMX = "Cumbre de Roca Negra Superior", enUS = "Upper Blackrock Spire", deDE = "Obere Schwarzfelsspitze", frFR = "Pic de Rochenoire supérieur", itIT = "Bastioni di Roccianera Superiori", koKR = "검은바위 첨탑 상층", ptBR = "Pico da Rocha Negra Superior", ruRU = "Верхняя часть Пика Черной горы", zhCN = "黑石塔上层", zhTW = "黑石塔上層" },
    ["scholo"] = { esES = "Scholomance", esMX = "Scholomance", enUS = "Scholomance", deDE = "Scholomance", frFR = "Scholomance", itIT = "Scholomance", koKR = "스콜로만스", ptBR = "قirmance", ruRU = "Некроситет", zhCN = "通灵学院", zhTW = "通靈學院" },
    ["mc"] = { esES = "Núcleo de Magma", esMX = "Núcleo de Magma", enUS = "Molten Core", deDE = "Geschmolzener Kern", frFR = "Cœur du Magma", itIT = "Nucleo Ardente", koKR = "화염의 심장", ptBR = "Núcleo de Magma", ruRU = "Огненные Недра", zhCN = "熔火之心", zhTW = "熔火之心" },
    ["bwl"] = { esES = "Guarida de l'Ala Negra", esMX = "Guarida de l'Ala Negra", enUS = "Blackwing Lair", deDE = "Pechschwingenhort", frFR = "Repaire de l'Aile noire", itIT = "Antro de l'Ala Nera", koKR = "검은날개 둥지", ptBR = "Guarida Asa Negra", ruRU = "Логово Крыла Тьмы", zhCN = "黑翼之巢", zhTW = "黑翼之巢" },

    -- === THE BURNING CRUSADE ===
    ["kara"] = { esES = "Karazhan", esMX = "Karazhan", enUS = "Karazhan", deDE = "Karazhan", frFR = "Karazhan", itIT = "Karazhan", koKR = "카라잔", ptBR = "Karazhan", ruRU = "Каражан", zhCN = "卡拉赞", zhTW = "卡拉贊" },
    ["bt"] = { esES = "Templo Oscuro", esMX = "Templo Oscuro", enUS = "Black Temple", deDE = "Der Schwarze Tempel", frFR = "Temple noir", itIT = "Tempio Oscuro", koKR = "검은 사원", ptBR = "Templo Negro", ruRU = "Черный храм", zhCN = "黑暗神殿", zhTW = "黑暗神殿" },
    ["mag"] = { esES = "Guarida de Magtheridon", esMX = "Guarida de Magtheridon", enUS = "Magtheridon's Lair", deDE = "Magtheridons Kammer", frFR = "Le repaire de Magtheridon", itIT = "Antro di Magtheridon", koKR = "마그테리돈의 둥지", ptBR = "Guarida do Magtheridon", ruRU = "Логово Магтеридона", zhCN = "玛瑟里顿的巢穴", zhTW = "玛瑟里顿的巢穴" },
    ["ssc"] = { esES = "Caverna Santuario Serpiente", esMX = "Caverna Santuario Serpiente", enUS = "Serpentshrine Cavern", deDE = "Höhle des Schlangenschreins", frFR = "Caverne du sanctuaire du Serpent", itIT = "Caverna del Santuario del Serpente", koKR = "불뱀 제단", ptBR = "Caverna Santuário das Serpentes", ruRU = "Змеиное святилище", zhCN = "毒蛇神殿", zhTW = "毒蛇神殿" },

    -- === WRATH OF THE LICH KING ===
    ["icc"] = { esES = "Corona de Hielo", esMX = " Corona de Hielo", enUS = "Icecrown Citadel", deDE = "Eiskronenzitadelle", frFR = "Citadelle de la Couronne de glace", itIT = "Cittadella della Corona di Ghiaccio", koKR = "얼음왕관 성채", ptBR = "Cidadela da Coroa de Gelo", ruRU = "Цитадель Ледяной Короны", zhCN = "冰冠堡垒", zhTW = "冰冠堡壘" },
    ["uld"] = { esES = "Ulduar", esMX = "Ulduar", enUS = "Ulduar", deDE = "Ulduar", frFR = "Ulduar", itIT = "Ulduar", koKR = "울두아르", ptBR = "Ulduar", ruRU = "Ульдуар", zhCN = "奥杜尔", zhTW = "奧杜爾" },
    ["naxx"] = { esES = "Naxxramas", esMX = "Naxxramas", enUS = "Naxxramas", deDE = "Naxxramas", frFR = "Naxxramas", itIT = "Naxxramas", koKR = "낙스라마스", ptBR = "Naxxramas", ruRU = "Наксрамас", zhCN = "纳克萨玛斯", zhTW = "納克薩瑪斯" },

    -- === CATACLYSM ===
    ["bot"] = { esES = "Bastión del Crepúsculo", esMX = "Bastión del Crepúsculo", enUS = "Bastion of Twilight", deDE = "Bastion des Zwielichts", frFR = "Bastion du Crépuscule", itIT = "Bastione del Crepuscolo", koKR = "황혼의 요새", ptBR = "Bastião do Crepúsculo", ruRU = "Бастион Сумерек", zhCN = "暮光堡垒", zhTW = "暮光堡壘" },
    ["bwd"] = { esES = "Descenso de l'Ala Negra", esMX = "Descenso de Alanegra", enUS = "Blackwing Descent", deDE = "Pechschwingenabstieg", frFR = "Descente de l'Aile noire", itIT = "Ascesa dell'Ala Nera", koKR = "검은날개 강림지", ptBR = "Descenso do Asa Negra", ruRU = "Твердыня Крыла Тьмы", zhCN = "黑翼血环", zhTW = "黑翼血環" },
    ["fl"] = { esES = "Tierras de Fuego", esMX = "Tierras de Fuego", enUS = "Firelands", deDE = "Feuerlande", frFR = "Terres de Feu", itIT = "Terre del Fuoco", koKR = "불의 땅", ptBR = "Terras do Fogo", ruRU = "Огненные Просторы", zhCN = "火焰之地", zhTW = "火焰之地" },
    ["ds"] = { esES = "Alma de Dragón", esMX = "Alma de Dragón", enUS = "Dragon Soul", deDE = "Drachenseele", frFR = "Âme des dragons", itIT = "Anima del Drago", koKR = "용의 영혼", ptBR = "Alma Dragônica", ruRU = "Душа Драcona", zhCN = "巨龙之魂", zhTW = "巨龍之魂" },

    -- === MISTS OF PANDARIA ===
    ["soo"] = { esES = "Asedio de Orgrimmar", esMX = "Asedio de Orgrimmar", enUS = "Siege of Orgrimmar", deDE = "Schlacht um Orgrimmar", frFR = "Siège d'Orgrimmar", itIT = "Assedio di Orgrimmar", koKR = "오그리마 공성전", ptBR = "Cerco de Orgrimmar", ruRU = "Осада Оргриммара", zhCN = "围攻奥格瑞玛", zhTW = "圍攻奧格瑞瑪" },
    ["tot"] = { esES = "Solio del Trueno", esMX = "Solio del Trueno", enUS = "Throne of Thunder", deDE = "Thron des Donners", frFR = "Trône du tonnerre", itIT = "Trono del Tuono", koKR = "천둥의 왕좌", ptBR = "Trono do Trovão", ruRU = "Престол Гроз", zhCN = "雷电王座", zhTW = "雷電王座" },
    ["msv"] = { esES = "Cámaras Mogu'shan", esMX = "Cámaras Mogu'shan", enUS = "Mogu'shan Vaults", deDE = "Mogu'shangewölbe", frFR = "Caveaux Mogu'shan", itIT = "Camere di Mogu'shan", koKR = "모구샨 금고", ptBR = "Galerias Mogu'shan", ruRU = "Подземелья Могу'шан", zhCN = "魔古山宝库", zhTW = "魔古山寶庫" },
    ["hof"] = { esES = "Corazón del Miedo", esMX = "Corazón del Miedo", enUS = "Heart of Fear", deDE = "Herz der Angst", frFR = "Cœur de la Peur", itIT = "Cuore della Paura", koKR = "공포의 심장", ptBR = "Coração do Medo", ruRU = "Сердце Страха", zhCN = "恐惧之心", zhTW = "恐懼之心" },
    ["toes"] = { esES = "Veranda de la Primavera Eterna", esMX = "Veranda de la Primavera Eterna", enUS = "Terrace of Endless Spring", deDE = "Terrasse des Endlosen Frühlings", frFR = "Terrasse Printemps éternel", itIT = "Terrazza dell'Eterna Primavera", koKR = "영원한 봄의 정원", ptBR = "Terraço de Primavera Eterna", ruRU = "Терраса Вечной Весны", zhCN = "永春台", zhTW = "永春台" },
    ["gal"] = { esES = "Galeón", esMX = "Galeón", enUS = "Galleon", deDE = "Galleon", frFR = "Galleon", itIT = "Galleon", koKR = "갈레온", ptBR = "Galleon", ruRU = "Галеон", zhCN = "萨尔里斯", zhTW = "萨尔里斯" },
}