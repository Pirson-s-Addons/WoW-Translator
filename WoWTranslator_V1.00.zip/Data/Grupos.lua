local ADDON_NAME, addonTable = ...
addonTable.GruposDict = {
    ["lfm"] = { 
        esES = "Busco más para", esMX = "Busco más para", enUS = "Looking for more", 
        deDE = "Suche mehr für", frFR = "Cherche plus pour", itIT = "Cerca altri per", 
        koKR = "공격대원 모집", ptBR = "Procuro mais para", ruRU = "Нужны еще в", 
        zhCN = "寻找更多队员", zhTW = "尋找更多隊員" 
    },
    ["lf1m"] = { 
        esES = "Busco 1 más para", esMX = "Busco 1 más para", enUS = "Looking for 1 more", 
        deDE = "Suche 1 weiteren für", frFR = "Cherche 1 de plus pour", itIT = "Cerca último per", 
        koKR = "1명 더 모집", ptBR = "Procuro mais 1 para", ruRU = "Нужен +1 в", 
        zhCN = "还缺1人", zhTW = "還缺1人" 
    },
    ["lf2m"] = { 
        esES = "Busco 2 más para", esMX = "Busco 2 más para", enUS = "Looking for 2 more", 
        deDE = "Suche 2 weitere für", frFR = "Cherche 2 de plus pour", itIT = "Cerca 2 altri per", 
        koKR = "2명 더 모집", ptBR = "Procuro mais 2 para", ruRU = "Нужны +2 в", 
        zhCN = "还缺2人", zhTW = "還缺2人" 
    },
    ["lf3m"] = { 
        esES = "Busco 3 más para", esMX = "Busco 3 más para", enUS = "Looking for 3 more", 
        deDE = "Suche 3 weitere für", frFR = "Cherche 3 de plus pour", itIT = "Cerca 3 altri per", 
        koKR = "3명 더 모집", ptBR = "Procuro más 3 para", ruRU = "Нужны +3 в", 
        zhCN = "还缺3人", zhTW = "還缺3人" 
    },
    ["lfg"] = { 
        esES = "Busco grupo para", esMX = "Busco grupo para", enUS = "Looking for group", 
        deDE = "Suche Gruppe für", frFR = "Cherche groupe pour", itIT = "Cerca gruppo per", 
        koKR = "파티 찾기", ptBR = "Procuro grupo para", ruRU = "Ищу группу в", 
        zhCN = "寻求组队", zhTW = "尋求組隊" 
    },
    ["lf"] = { 
        esES = "Busco para", esMX = "Busco para", enUS = "Looking for", 
        deDE = "Suche für", frFR = "Cherche pour", itIT = "Cerca per", 
        koKR = "찾고 있음", ptBR = "Procuro para", ruRU = "Ищу в", 
        zhCN = "寻找", zhTW = "尋找" 
    },
    ["fresh"] = { 
        esES = "Desde el inicio", esMX = "Desde el inicio", enUS = "New run", 
        deDE = "Neu", frFR = "Neuf", itIT = "Nuovo", koKR = "새로 시작", 
        ptBR = "Limpo", ruRU = "С начала", zhCN = "新进度", zhTW = "新進度" 
    },
    ["last spot"] = { 
        esES = "Último cupo", esMX = "Último cupo", enUS = "Last spot", deDE = "Letzter Platz", 
        frFR = "Dernière place", itIT = "Ultimo posto", koKR = "마지막 자리", 
        ptBR = "Última vaga", ruRU = "Последнее место", zhCN = "最后一名", zhTW = "最後一名" 
    },
    ["hc"] = { 
        esES = "Heroico", esMX = "Heroico", enUS = "Heroic", deDE = "Heroisch", 
        frFR = "Héroïque", itIT = "Eroico", koKR = "영웅", ptBR = "Heroico", 
        ruRU = "Хероик/ХМ", zhCN = "英雄难度", zhTW = "英雄難度" 
    },
    ["10hc"] = { 
        esES = "10 Heroico", esMX = "10 Heroico", enUS = "10-man Heroic", deDE = "10er Heroisch", 
        frFR = "10 Héroïque", itIT = "10 Eroico", koKR = "10인 영웅", ptBR = "10 jogadores Heroico", 
        ruRU = "10 ХМ", zhCN = "10人英雄", zhTW = "10人英雄" 
    },
    ["25hc"] = { 
        esES = "25 Heroico", esMX = "25 Heroico", enUS = "25-man Heroic", deDE = "25er Heroisch", 
        frFR = "25 Héroïque", itIT = "25 Eroico", koKR = "25인 영웅", ptBR = "25 jugadores Heroico", 
        ruRU = "25 ХМ", zhCN = "25人英雄", zhTW = "25人英雄" 
    },
    ["nm"] = { 
        esES = "Normal", esMX = "Normal", enUS = "Normal", deDE = "Normal", 
        frFR = "Normal", itIT = "Normale", koKR = "일반", ptBR = "Normal", 
        ruRU = "Нормал/Обычка", zhCN = "普通难度", zhTW = "普通難度" 
    },
    ["10nm"] = { 
        esES = "10 Normal", esMX = "10 Normal", enUS = "10-man Normal", deDE = "10er Normal", 
        frFR = "10 Normal", itIT = "10 Normale", koKR = "10인 일반", ptBR = "10 jugadores Normal", 
        ruRU = "10 ОБ", zhCN = "10人普通", zhTW = "10人普通" 
    },
    ["25nm"] = { 
        esES = "25 Normal", esMX = "25 Normal", enUS = "25-man Normal", deDE = "25er Normal", 
        frFR = "25 Normal", itIT = "25 Normale", koKR = "25인 일반", ptBR = "25 jugadores Normal", 
        ruRU = "25 ОБ", zhCN = "25人普通", zhTW = "25人普通" 
    },
    ["10m"] = { 
        esES = "10 jugadores", esMX = "10 jugadores", enUS = "10-man", deDE = "10er", 
        frFR = "10 joueurs", itIT = "10 giocatori", koKR = "10인", ptBR = "10 jogadores", 
        ruRU = "10 чел", zhCN = "10人", zhTW = "10人" 
    },
    ["25m"] = { 
        esES = "25 jugadores", esMX = "25 jugadores", enUS = "25-man", deDE = "25er", 
        frFR = "25 joueurs", itIT = "25 giocatori", koKR = "25인", ptBR = "25 jogadores", 
        ruRU = "25 чел", zhCN = "25人", zhTW = "25人" 
    },
    ["need"] = { 
        esES = "Necesito", esMX = "Necesito", enUS = "Need", deDE = "Suche", 
        frFR = "Besoin", itIT = "Serve", koKR = "필요", ptBR = "Preciso", 
        ruRU = "Нужен", zhCN = "需要", zhTW = "需要" 
    },
    ["rf"] = { 
        esES = "Buscador de Bandas", esMX = "Buscador de Bandas", enUS = "LFR/Raid Finder", deDE = "LFR", 
        frFR = "Raid Finder", itIT = "Ricerca delle Incursioni", koKR = "공격대 찾기", ptBR = "Localizador de Raides", 
        ruRU = "ЛФР", zhCN = "随机团队", zhTW = "隨機團隊" 
    },
    ["lfr"] = { 
        esES = "Buscador de Bandas", esMX = "Buscador de Bandas", enUS = "LFR/Raid Finder", deDE = "LFR", 
        frFR = "Raid Finder", itIT = "Ricerca delle Incursioni", koKR = "공격대 찾기", ptBR = "Localizador de Raides", 
        ruRU = "ЛФР", zhCN = "随机团队", zhTW = "隨機團隊" 
    },
    ["ilvl"] = { 
        esES = "Nivel de objeto", esMX = "Nivel de objeto", enUS = "Item Level", deDE = "Gegenstandsstufe", 
        frFR = "Niveau d'objet", itIT = "Livello oggetto", koKR = "아이템 레벨", ptBR = "Nível de Item", 
        ruRU = "Илвл", zhCN = "物品等级", zhTW = "物品等級" 
    },
    ["lvl"] = { 
        esES = "Nivel", esMX = "Nivel", enUS = "Level", deDE = "Stufe", 
        frFR = "Niveau", itIT = "Livello", koKR = "레벨", ptBR = "Nível", 
        ruRU = "Лвл", zhCN = "等级", zhTW = "等級" 
    },
    ["achiev"] = { 
        esES = "Logro", esMX = "Logro", enUS = "Achievement", deDE = "Erfolg", 
        frFR = "Haut fait", itIT = "Impresa", koKR = "업적", ptBR = "Conquista", 
        ruRU = "Ачив", zhCN = "成就", zhTW = "成就" 
    },
    ["achieve"] = { 
        esES = "Logro", esMX = "Logro", enUS = "Achievement", deDE = "Erfolg", 
        frFR = "Haut fait", itIT = "Impresa", koKR = "업적", ptBR = "Conquista", 
        ruRU = "Ачив", zhCN = "成就", zhTW = "成就" 
    },
    ["achv"] = { 
        esES = "Logro", esMX = "Logro", enUS = "Achievement", deDE = "Erfolg", 
        frFR = "Haut fait", itIT = "Impresa", koKR = "업적", ptBR = "Conquista", 
        ruRU = "Ачив", zhCN = "成就", zhTW = "成就" 
    },
    ["exp"] = { 
        esES = "Experiencia", esMX = "Experiencia", enUS = "Experience", deDE = "Erfahrung", 
        frFR = "Expérience", itIT = "Esperienza", koKR = "경험", ptBR = "Experiência", 
        ruRU = "Опыт/ХР", zhCN = "经验", zhTW = "經驗" 
    },
    ["xp"] = { 
        esES = "Experiencia", esMX = "Experiencia", enUS = "Experience", deDE = "Erfahrung", 
        frFR = "Expérience", itIT = "Esperienza", koKR = "경험", ptBR = "Experiência", 
        ruRU = "Опыт/ХР", zhCN = "经验", zhTW = "經驗" 
    },
    ["link"] = { 
        esES = "Vincular/Mostrar", esMX = "Vincular/Mostrar", enUS = "Link item/achievement", 
        deDE = "Verlinken", frFR = "Lien", itIT = "Linka", koKR = "링크", 
        ptBR = "Linkar", ruRU = "Линк/Ссылку", zhCN = "链接", zhTW = "連結" 
    },
    ["gear"] = { 
        esES = "Equipo", esMX = "Equipo", enUS = "Gear/Equipment", deDE = "Ausrüstung", 
        frFR = "Équipement", itIT = "Equipaggiamento", koKR = "장비", ptBR = "Equipamento", 
        ruRU = "Шмот/Эквип", zhCN = "装备", zhTW = "裝備" 
    },
    ["req"] = { 
        esES = "Requisito", esMX = "Requisito", enUS = "Requirement", deDE = "Anforderung", 
        frFR = "Condition", itIT = "Requisito", koKR = "요구사항", ptBR = "Requisito", 
        ruRU = "Требование", zhCN = "要求", zhTW = "要求" 
    },
}