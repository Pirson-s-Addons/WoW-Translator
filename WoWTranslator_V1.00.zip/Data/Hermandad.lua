local ADDON_NAME, addonTable = ...
addonTable.HermandadDict = {
    ["guild"] = { 
        esES = "Hermandad", esMX = "Hermandad", enUS = "Guild", deDE = "Gilde", 
        frFR = "Guilde", itIT = "Gilda", koKR = "길드", ptBR = "Guilda", 
        ruRU = "Гильдия", zhCN = "公会", zhTW = "公會" 
    },
    ["gm"] = { 
        esES = "Maestro de Hermandad", esMX = "Maestro de Hermandad", enUS = "Guild Master", deDE = "Gildenmeister", 
        frFR = "Maître de guilde", itIT = "Capogilda", koKR = "길드장", ptBR = "Mestre da Guilda", 
        ruRU = "GМ (ГМ)", zhCN = "会长", zhTW = "會長" 
    },
    ["officer"] = { 
        esES = "Oficial", esMX = "Oficial", enUS = "Officer", deDE = "Offizier", 
        frFR = "Officier", itIT = "Ufficiale", koKR = "관리자", ptBR = "Oficial", 
        ruRU = "Офицер", zhCN = "官员", zhTW = "官員" 
    },
    ["recruit"] = { 
        esES = "Recluta", esMX = "Reclutando", enUS = "Recruiting", deDE = "Rekrutierung", 
        frFR = "Recrutement", itIT = "Reclutamento", koKR = "모집", ptBR = "Recrutando", 
        ruRU = "Набор", zhCN = "招募", zhTW = "招募" 
    },
    ["gbank"] = { 
        esES = "Banco de hermandad", esMX = "Banco de hermandad", enUS = "Guild Bank", deDE = "Gildenbank", 
        frFR = "Banque de guilde", itIT = "Banca di gilda", koKR = "길드 창고", ptBR = "Banco da guilda", 
        ruRU = "ГБ (Гильд банк)", zhCN = "公会仓库", zhTW = "公會倉庫" 
    }
}